
    class Personnage {
        constructor(pseudo,classe,sante,attaque,niveau=1){
            this.pseudo = pseudo;
            this.classe = classe;
            this.sante =sante;
            this.attaque = attaque;
            this.niveau = niveau ;
        
        }
        evoluer(){
            console.log("Vous avez gagné un niveau gg")
            this.niveau ++;
            console.log(this.getInformations)
        }
        verifierSante(){
            if (this.sante <= 0) {
                this.sante = 0
                console.log(`${this.pseudo} est un gros looser il a perdu`)
            }
        }
        get getInformations(){
            console.log(`${this.pseudo} le ${this.classe } a ${this.sante } points de vie et est au niveau ${this.niveau}`)
        }
    }

    let leVoleur = new Personnage("José le fielleux","Voleur",100,"attaque sournoise")

    class Magicien extends Personnage{
        constructor (pseudo,classe,sante,attaque,niveau){
            super(pseudo,"Magicien",170,90,niveau);
         }
    attaquer(adversaire){
        adversaire.sante -= this.attaque;
        console.log(`${this.pseudo} attaque ${adversaire.pseudo} en lançant un sort qui retire ${this.attaque }  points de vie`);
        this.evoluer();
        adversaire.verifierSante()
    }
    coupSpecial(adversaire){
        adversaire.sante -= this.attaque*5;
        console.log(`${this.pseudo} attaque avec son coup spécial "aracane secrète de la puissance de Konoha" ${adversaire.pseudo} en lançant un sort qui retire ${this.attaque*5 }  points de vie et procure 1000 ans de souffrance`);
        this.evoluer();
        adversaire.verifierSante()  
    }
    }

let rincevent = new Magicien(" Rincevent");

rincevent.Magicien;


console.log(rincevent)
console.log(leVoleur)


    class Guerrier extends Personnage{
        constructor (pseudo,classe,sante,attaque,niveau){
            super(pseudo,"Guerrier",350,50,niveau);
        }
    attaquer1(adversaire1){
        adversaire1.sante -= this.attaque;
        console.log(`${this.pseudo} attaque ${adversaire1.pseudo} en lançant une  coup d'épée rotatif aléatoire qui retire ${this.attaque }  points de vie`);
        this.evoluer();
        adversaire1.verifierSante()
    }
    coupSpecial1(adversaire1){
        adversaire1.sante -= this.attaque*5;
        console.log(`${this.pseudo} attaque avec son coup spécial "grosse tarte de maçon" ${adversaire1.pseudo} en lançant une pluie de baffes qui retirent ${this.attaque*5 }  points de vie `);
        this.evoluer();
        adversaire1.verifierSante()  
    }
    
    // berserk(){
    //     if (this.sante <= 0) {
    //         this.sante = 1
    //         console.log(`${this.pseudo} passe en mode Berserker et lance ${this.coupSpecial}`)
    //     }
    // }
}
let barbare = new Guerrier("Connard le Barbant");





console.log(barbare.informations);
console.log(rincevent.informations); 
rincevent.attaquer(barbare); 
console.log(barbare.informations); 
barbare.attaquer1(rincevent); 
console.log(rincevent.informations); 
rincevent.coupSpecial(barbare);

